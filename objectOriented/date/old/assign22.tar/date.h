/***********************************************************************
* Program:
*    Assignment ##, ???? 
*    Brother Helfrich, CS165
* Author:
*    your name
* Summary: 
*    This header file describes all the interfaces associated with
*    manipulating dates.
************************************************************************/

#ifndef DATE_H
#define DATE_H

#include <string>
using std::string;

//
// Date structure
//

class Date
{
  private:
   int daysMonth(int month, int year);
   bool isLeapYear(int year);
   int *data;  // dynamically allocated
   void assertDate();
  public:
   void initialize();
   void uninitialize();
   bool setDate(int year, int month, int day);
   bool setYear(int year);
   bool setMonth(int month);
   bool setDay(int day);
   void displayLong();
};

#endif
