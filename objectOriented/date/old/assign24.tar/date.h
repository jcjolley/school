/***********************************************************************
* Program:
*    Assignment ##, ???? 
*    Brother Helfrich, CS165
* Author:
*    your name
* Summary: 
*    This header file describes all the interfaces associated with
*    manipulating dates.
************************************************************************/

#ifndef DATE_H
#define DATE_H

#include <string>
using std::string;

enum {DAY, MONTH, YEAR};

//
// Date structure
//

class Date
{
  public:
   Date(int year, int month = 1, int day = 1);
   Date();
   Date(Date & temp);
   
   bool setDate(int year, int month, int day);
   bool setYear(int year);
   bool setMonth(int month);
   bool setDay(int day);
   int  getDay()   const { return data[DAY];   }
   int  getMonth() const { return data[MONTH]; }
   int  getYear()  const { return data[YEAR];  }
   void displayLong();

   ~Date();

  private:
   void allocate();
   void adjustDay  (int adjustment);
   void adjustMonth(int adjustment);
   void adjustYear (int adjustment);
   int daysMonth(int month, int year);
   bool isLeapYear(int year);
   int *data;  // dynamically allocated
   void assertDate();

};

#endif
